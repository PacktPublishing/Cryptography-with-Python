text = raw_input("Enter text: ")
n = len(text)

for i in range(n):
  t = text[i]
  print t
 
