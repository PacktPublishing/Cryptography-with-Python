print "HELLO"
